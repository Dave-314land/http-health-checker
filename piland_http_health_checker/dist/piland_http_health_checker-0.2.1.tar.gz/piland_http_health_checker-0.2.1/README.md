# piland_http_health_checker

A program to check the health of a set of HTTP endpoints